# SQL-Analysis
Analyze sales team impact! Join employee, interaction (timestamps &amp; IDs), and sales data (timestamps &amp; IDs) to assign credit (last/first touch or multi-touch) via SQL. Identify top performers and optimize workflows.
